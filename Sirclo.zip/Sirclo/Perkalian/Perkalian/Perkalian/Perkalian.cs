﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Perkalian
{
    class Perkalian
    {
        static void Main(string[] args)
        {

            int NumOne, NumTwo; // Declare Variable angka 1 dan 2

            System.Console.Write("Angka 1 : ");
            NumOne = int.Parse(System.Console.In.ReadLine()); //Input angka 1
            System.Console.Write("Angka 2 : ");
            NumTwo = int.Parse(System.Console.In.ReadLine());//Input angka 2

            string result = Kali(NumOne, NumTwo); // Panggil Method Kali
            System.Console.WriteLine(result); // Cetak hasil
            System.Console.ReadLine();
        }

        static string Kali(int NumOne, int NumTwo)
        {
            int multiple = 0;
            string result;

            for (int i = 0; i < NumTwo; i++) //for untuk i sejumlah <  NumTwo
            {
                multiple += NumOne;   // ex : 3*3 =  3 + 3 + 3
            }
            result = "=> " + multiple; // cetak
            return result;
        }
    }
}
