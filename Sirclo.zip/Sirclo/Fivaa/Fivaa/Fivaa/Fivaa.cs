﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fivaa
{
    class Fivaa
    {
        static void Main(string[] args)
        {
            int NumOne;
            System.Console.Write("Batas : ");
            NumOne = int.Parse(System.Console.In.ReadLine()); //Input Batas Segitiga

            Cetak(NumOne); // Panggil Method Cetak
        }

        static void Cetak(int NumOne)
        {
            for (int i = NumOne; i >= 1; i--) //for pertama untuk menentukan jumlah row yg akan dicetak
            {
                Console.Write(i - 1); // Cetak untuk 2 angka didepan (- 1)
                Console.Write(i - 1);

                for (int j = i; j >= 1; j--) //for kedua untuk menentukan jumlah angka / i yg akan dicetak dlm 1 row
                {

                    Console.Write(i + 1); // cetak angka + 1 sejumlah i
                }
                Console.WriteLine(); // ganti baris
            }
            System.Console.ReadLine();
        }
    }
}
