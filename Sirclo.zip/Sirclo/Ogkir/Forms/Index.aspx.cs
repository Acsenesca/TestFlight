﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ogkir.Forms
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int Berat = int.Parse(txtBerat.Text); //declare variable untuk txtBerat
            int Provider = int.Parse(ddlProvider.SelectedValue);  // declare variable untuk value ddlProvider
            decimal result = 0;

            result = Cek(Provider, Berat); // panggil method cek
         
            lblTotal.Text = "Rp. " + result.ToString() + ",-"; // cetak hasil
            ddlProvider.SelectedValue = "1";  // Set Default Reguler 

        }


        public decimal Cek(int Provider, int Berat)
        {
            decimal result = 0 ;
            decimal harga = 9000; //hardcode harga

            if (Provider == 1)
            {
                result = Berat * harga;  // proses untuk Reguler
            }
            else if (Provider == 2)
            {
                result = Berat * harga * 2;  // proses untuk Express 
            }
            else if (Provider == 3)
            {
                result = Berat * harga * 5; // proses untuk Instant 
            }

            return result;
    
        }
    }
}