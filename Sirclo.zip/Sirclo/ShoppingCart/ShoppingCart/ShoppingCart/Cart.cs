﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    class Cart
    {
        static void Main(string[] args) //Method Main
        {
            int Kuantitas;
            string KodeProduk;

            while (true) // looping untuk selalu kembali ke menu
            {
                int DoWhat = DisplayMenu();  // Tampilan Menu Utama

                if (DoWhat == 1) // kondisi tambah produk
                {
                    System.Console.Write("Masukkan Nama Barang : ");
                    KodeProduk = System.Console.In.ReadLine();     //Input Kode produk
                    System.Console.Write("Masukkan Jumlah Barang : ");
                    Kuantitas = int.Parse(System.Console.In.ReadLine());  //Input Jumlah produk
                    TambahProduk(KodeProduk, Kuantitas);    //panggil method tambah produk
                }
                if (DoWhat == 2) //kondisi hapus produk
                {
                    System.Console.Write("Masukkan Nama Barang : ");
                    KodeProduk = System.Console.In.ReadLine(); //Input Kode Barang
                    HapusProduk(KodeProduk);   // panggil method HapusProduk
                }
                else if (DoWhat == 3)// kondisi tampil produk
                {
                    TampilProduk(); // Panggil method tampilProduk
                }
            }
        }

        public static List<Produk> listProduk = new List<Produk>();

        public class Produk //Buat Class Produk
        {
            public Produk() { } // constructor
            public Produk(Produk Prd)
            {
                KodeProduk = Prd.KodeProduk;
                Kuantitas = Prd.Kuantitas;
            } // constructor dengan parameter
            public string KodeProduk { get; set; }
            public int Kuantitas { get; set; }
        }

        public static int DisplayMenu() // method tampil menu utama
        {
            int DoWhat;
            System.Console.Write("Produk (1)Tambah (2)Hapus (3)Tampil ? ");
            DoWhat = int.Parse(System.Console.In.ReadLine()); //Input mau lakuin apa tambah, hapus, tampil
            return DoWhat; // balikan 

        }

        public static void TambahProduk(string KodeProduk, int Kuantitas) //Method Tambah produk
        {
            Produk Produk = new Produk(); // Object produk
            Produk.KodeProduk = KodeProduk; // Declare 
            Produk.Kuantitas = Kuantitas;

            listProduk.Add(new Produk(Produk)); // add barang to List 
        }

        public static void TampilProduk() //Method Tampil produk
        {

            //LinQ untuk menjumlahkan kuantitas per kode produk
            var groupedList = listProduk.GroupBy(item => item.KodeProduk)
                                        .Select(x => new { SumKuantitas = x.Sum(g => g.Kuantitas), KodeProduk = x.Key });

            foreach (var item in groupedList) // Looping sebanyak kode produk
            {
                var KodeProduk = item.KodeProduk; // Declare
                var Kuantitas = item.SumKuantitas;

                Console.WriteLine(KodeProduk + "(" + Kuantitas + ")"); // cetak 
            }
        }

        public static void HapusProduk(string KodeProduk) //Method Untuk hapus produk
        {
            listProduk.RemoveAll(item => item.KodeProduk == KodeProduk);//LinQ untuk get kode produk di list dan hapus produk
        }


    }
}
