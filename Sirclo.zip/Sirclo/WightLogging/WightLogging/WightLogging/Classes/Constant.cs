﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WightLogging.Classes
{
    public class Constant
    {
        public static string Connection = ConfigurationManager.ConnectionStrings["ConString"].ToString(); // koneski di webconfig

        public static void Insert(string Tanggal, int Max, int Min)
        {
            using (SqlConnection conn = new SqlConnection(Connection))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = "Insert into MSWightLogging (Tanggal, Max, Min ) Values(@Tanggal, @Max,@Min)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new SqlParameter("Tanggal", Tanggal));
                    cmd.Parameters.Add(new SqlParameter("Max", Max));
                    cmd.Parameters.Add(new SqlParameter("Min", Min));
                    SqlDataAdapter oAdapter = new SqlDataAdapter();
                    oAdapter.SelectCommand = cmd;

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {                   
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public static void Update(string Tanggal, int Max, int Min) 
        {
            using (SqlConnection conn = new SqlConnection(Connection))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = "Update MSWightLogging set Max = @Max, Min = @Min where Tanggal = @Tanggal";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new SqlParameter("Tanggal", Tanggal));
                    cmd.Parameters.Add(new SqlParameter("Max", Max));
                    cmd.Parameters.Add(new SqlParameter("Min", Min));
                    SqlDataAdapter oAdapter = new SqlDataAdapter();
                    oAdapter.SelectCommand = cmd;

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public static DataTable GetData()
        {             
            DataTable data = new DataTable();
            using (SqlConnection conn = new SqlConnection(Connection))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = "Select Tanggal, Max, Min, Max - Min as Perbedaan From MSWightLogging";
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter oAdapter = new SqlDataAdapter();
                    oAdapter.SelectCommand = cmd;

                    oAdapter.Fill(data);
                    oAdapter.Dispose();
                }
                catch (Exception ex)
                {               
                    throw;
                }
                finally
                {
                    conn.Close();
                }          
            }
            return data;
        }

        public static DataTable GetDataTanggal(string Tanggal)
        {
            DataTable data = new DataTable();
            using (SqlConnection conn = new SqlConnection(Connection))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandText = "Select Tanggal, Max, Min, Max - Min as Perbedaan From MSWightLogging where Tanggal = @Tanggal";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new SqlParameter("Tanggal", Tanggal));
                    SqlDataAdapter oAdapter = new SqlDataAdapter();
                    oAdapter.SelectCommand = cmd;

                    oAdapter.Fill(data);
                    oAdapter.Dispose();
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
            return data;
        }



       
    }
}