﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WightLogging.Classes;

namespace WightLogging.Forms
{
    public partial class AddNew : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtDate.Attributes.Add("readonly", "readonly");
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtDate.Text = Calendar1.SelectedDate.ToString("yyyy-MM-dd");
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string Date = txtDate.Text;
            int Max = int.Parse(txtMax.Text);
            int Min = int.Parse(txtMin.Text);
            Constant.Insert(Date, Max, Min);

            txtDate.Text = "";
            txtMax.Text = "";
            txtMin.Text = "";
        }
    }
}