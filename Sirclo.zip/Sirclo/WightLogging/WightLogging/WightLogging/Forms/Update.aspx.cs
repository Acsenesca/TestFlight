﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WightLogging.Classes;

namespace WightLogging.Forms
{
    public partial class Update : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string Tanggal = Request.QueryString["Tanggal"].ToString();
            int Max = int.Parse(txtMax.Text);
            int Min = int.Parse(txtMin.Text);

            Constant.Update(Tanggal, Max, Min);

            txtMax.Text = "";
            txtMin.Text = "";
        }
    }
}