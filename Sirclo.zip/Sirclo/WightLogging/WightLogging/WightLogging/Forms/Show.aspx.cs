﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WightLogging.Classes;

namespace WightLogging.Forms
{
    public partial class Show : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Bind();
        }

        void Bind()
        {
            string Tanggal= Request.QueryString["Tanggal"].ToString();
            DataTable dt = Constant.GetDataTanggal(Tanggal);
            gvList.DataSource = dt;
            gvList.DataBind();
            gvList.HeaderRow.HorizontalAlign = HorizontalAlign.Left;
        }

    }
}