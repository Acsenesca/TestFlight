﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WightLogging.Classes;

namespace WightLogging.Forms
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindData();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/AddNew.aspx");
        }

        private void BindData()
        {
            DataTable dt = Constant.GetData();
            gv.DataSource = dt;
            gv.DataBind();
        }

        protected void gvShow_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SelectShow")
            {
                string[] splitedText = e.CommandArgument.ToString().Split('|');
                string commandValue1 = splitedText[0];
                string webUrl = "";
                webUrl = "~/Forms/Show.aspx";
                string response = string.Format(webUrl + "?Tanggal={0}", commandValue1);
                Response.Redirect(ResolveUrl(response));
            }

            else if (e.CommandName == "SelectUpdate")
            {
                string[] splitedText = e.CommandArgument.ToString().Split('|');
                string commandValue1 = splitedText[0];
                string webUrl = "";
                webUrl = "~/Forms/Update.aspx";
                string response = string.Format(webUrl + "?Tanggal={0}", commandValue1);
                Response.Redirect(ResolveUrl(response));
            }
        }
    }
}